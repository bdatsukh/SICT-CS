def encrypt_number(number, step):
