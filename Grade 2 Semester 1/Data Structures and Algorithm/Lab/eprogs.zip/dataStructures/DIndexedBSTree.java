/** indexed binary search tree with duplicates */

package dataStructures;

public interface DIndexedBSTree extends IndexedBSTree
   {}
