/** A class that has an integer data member named score. */

package dataStructures;

public class ScoreObject
{
   int score;

   /** constructor */
   public ScoreObject(int theScore)
      {score = theScore;}
}
