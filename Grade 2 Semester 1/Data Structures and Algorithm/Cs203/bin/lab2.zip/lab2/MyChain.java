package lab2;

import java.util.HashSet;
import java.util.Arrays;

import dataStructures.Chain;
import dataStructures.ChainNode;
import dataStructures.ScoreObject;

public class MyChain extends Chain{

	public Object[] toArray() {
		Object[] array = new Object[size];
		
		for(int i = 0; i < size; i++) {
			array[i] = get(i);
		}
		
		return array;
	}
	
	public void addRange(Object[] elements) {
		
		if(elements.length == 0)
			throw new NullPointerException
				("Array is empty");
	
		if(this.isEmpty()) {
			for(int i = 0; i < elements.length; i++) {
				this.add(i, elements[i]);
			}
			
			return;
		}

		ChainNode currentNode = this.firstNode;
		
		for(int i = 0; i < this.size() - 1; i++)
			currentNode = currentNode.next;
		
		for(int i = 0; i < elements.length - 1; i++) {
			currentNode.next = new ChainNode(elements[i], currentNode.next);
			currentNode = currentNode.next;
		}
		
		currentNode.next = new ChainNode(elements[elements.length - 1], currentNode.next);
  
		this.size += elements.length;
	}
	
	public MyChain union(MyChain chain) {
		MyChain result = new MyChain();
		
		Object[] thisArray = this.toArray();
		Object[] chainArray = chain.toArray();
		
		HashSet<Object> set = new HashSet<Object>();
		set.addAll(Arrays.asList(thisArray));
		set.addAll(Arrays.asList(chainArray));
		
		result.addRange(set.toArray());
		
		return result;
		
		/*MyChain result = new MyChain();
		
		result.addRange(this.toArray());
		result.addRange(chain.toArray());
		
		for(int i = 0; i < result.size(); i++) {
			
			for(int j = i + 1; j < result.size(); j++) {
				if(result.get(i).equals(result.get(j))) {
					result.remove(i);
					i--;
					break;
				}
			}
			
		}
		
		return result;*/
	}
	
	public MyChain intersection(MyChain chain) {
		MyChain result = new MyChain();
		
		Object[] thisArray = this.toArray();
		Object[] chainArray = chain.toArray();
		HashSet<Object> set = new HashSet<Object>();
		set.addAll(Arrays.asList(thisArray));
		set.retainAll(Arrays.asList(chainArray));
		
		result.addRange(set.toArray());
		
		return result;
	}
	
}
